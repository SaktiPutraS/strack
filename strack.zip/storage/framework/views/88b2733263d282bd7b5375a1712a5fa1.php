<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-3">
                <div>
                    <h1 class="h2 fw-bold text-purple mb-1">
                        <i class="bi bi-house-door me-2"></i>Dashboard
                    </h1>
                    <?php if(!$isMobile): ?>
                        <p class="text-muted mb-0"><?php echo e(now()->format('F Y')); ?> • Selamat datang kembali</p>
                    <?php endif; ?>
                </div>
                <div>
                    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary flex-fill flex-sm-grow-0">
                        <i class="bi bi-plus-circle me-1"></i>Proyek Baru
                    </a>
                    <a href="<?php echo e(route('financial-reports.index')); ?>" class="btn btn-outline-primary flex-fill flex-sm-grow-0">
                        <i class="bi bi-chart-bar me-1"></i>Laporan
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Project Status Cards -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <h5 class="text-uppercase text-muted fw-bold mb-3 fs-6">
                <i class="bi bi-kanban me-2 text-purple"></i>Status Proyek
            </h5>
        </div>

        <div class="col-6 col-md-6">
            <div class="card luxury-card stat-card stat-card-warning h-100 clickable-card" data-filter="status=WAITING">
                <div class="card-body text-center p-3">
                    <div class="luxury-icon mx-auto mb-2">
                        <i class="bi bi-clock-history text-warning fs-4"></i>
                    </div>
                    <h3 class="fw-bold text-warning mb-1"><?php echo e($proyekMenunggu); ?></h3>
                    <small class="text-muted fw-semibold">Menunggu</small>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6">
            <div class="card luxury-card stat-card stat-card-purple h-100 clickable-card" data-filter="status=PROGRESS">
                <div class="card-body text-center p-3">
                    <div class="luxury-icon mx-auto mb-2">
                        <i class="bi bi-play-circle-fill text-purple fs-4"></i>
                    </div>
                    <h3 class="fw-bold text-purple mb-1"><?php echo e($proyekProgress); ?></h3>
                    <small class="text-muted fw-semibold">Progress</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Financial Summary -->
    <div class="row g-3 mb-4">
        <div class="col-12">
            <h5 class="text-uppercase text-muted fw-bold mb-3 fs-6">
                <i class="bi bi-bar-chart me-2 text-purple"></i>Statistik Keuangan
            </h5>
        </div>

        <!-- Line Chart -->
        <div class="col-12 col-lg-8">
            <div class="card luxury-card border-0 h-100">
                <div class="card-header bg-white border-0 p-4">
                    <h5 class="fw-bold mb-0">
                        <i class="bi bi-graph-up me-2 text-purple"></i>Pendapatan & Pengeluaran
                    </h5>
                    <p class="text-muted mb-0">Akumulasi per minggu tahun ini (dimulai Juli 2025)</p>
                </div>
                <div class="card-body">
                    <canvas id="lineChart" height="250"></canvas>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-12 col-lg-4">
            <div class="card luxury-card border-0 h-100">
                <div class="card-header bg-white border-0 p-4">
                    <h5 class="fw-bold mb-0">Asset
                    </h5>
                    <p class="text-muted mb-0">Total:
                        <strong>Rp. <?php echo e(number_format($pieData['total'])); ?></strong>
                    </p>
                </div>
                <div class="card-body position-relative">
                    <canvas id="pieChart" height="250"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Upcoming Deadlines -->
    <div class="row">
        <div class="col-12">
            <div class="card luxury-card border-0">
                <div class="card-header bg-white border-0 p-4">
                    <div>
                        <h4 class="fw-bold mb-1">
                            <i class="bi bi-calendar-event text-purple me-2"></i>Deadline Terdekat
                        </h4>
                        <p class="text-muted mb-0">Proyek yang segera jatuh tempo</p>
                    </div>
                </div>

                <div class="card-body p-0">
                    <?php if($proyekDeadlineTermedekat->count() > 0): ?>
                        <div class="row g-3 p-3">
                            <?php $__currentLoopData = $proyekDeadlineTermedekat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12">
                                    <div class="card luxury-card project-card border-0 project-card" data-url="<?php echo e(route('projects.show', $project)); ?>">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="flex-grow-1">
                                                    <h6 class="fw-bold mb-1"><?php echo e($project->title); ?></h6>
                                                    <div class="d-flex align-items-center mb-1">
                                                        <i class="bi bi-person-fill text-purple me-1 fs-7"></i>
                                                        <small class="text-muted"><?php echo e($project->client->name); ?></small>
                                                    </div>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-calendar-date text-purple me-1 fs-7"></i>
                                                        <small class="fw-medium"><?php echo e($project->deadline->format('d M Y')); ?></small>
                                                    </div>
                                                </div>
                                                <div class="text-end">
                                                    <?php if($project->status == 'WAITING'): ?>
                                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning rounded-pill">
                                                            MENUNGGU
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="badge bg-purple-light text-purple border border-purple rounded-pill">
                                                            PROGRESS
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <!-- Empty State -->
                        <div class="text-center py-5">
                            <div class="luxury-icon mx-auto mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-calendar-check text-purple" style="font-size: 2.5rem;"></i>
                            </div>
                            <h5 class="fw-bold mb-2">Tidak ada deadline mendekat</h5>
                            <p class="text-muted mb-4">Semua proyek dalam kondisi aman</p>
                            <div class="d-flex flex-column flex-sm-row gap-2 justify-content-center">
                                <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary">
                                    <i class="bi bi-plus-circle me-2"></i>Proyek Baru
                                </a>
                                <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-outline-primary">
                                    <i class="bi bi-list-task me-2"></i>Lihat Proyek
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Clickable cards navigation
            const clickableCards = document.querySelectorAll('.clickable-card');

            clickableCards.forEach(card => {
                card.style.cursor = 'pointer';

                // Touch feedback for mobile
                card.addEventListener('touchstart', function() {
                    this.style.transform = 'scale(0.98)';
                    this.style.transition = 'transform 0.1s ease';
                }, {
                    passive: true
                });

                card.addEventListener('touchend', function() {
                    this.style.transform = 'scale(1)';
                    this.style.transition = 'transform 0.2s ease';
                }, {
                    passive: true
                });

                // Click handler
                card.addEventListener('click', function() {
                    const filter = this.getAttribute('data-filter');
                    if (filter) {
                        // Add loading state
                        this.style.opacity = '0.7';

                        // Navigate
                        setTimeout(() => {
                            window.location.href = `<?php echo e(route('projects.index')); ?>?${filter}`;
                        }, 100);
                    }
                });

                // Hover effect for desktop
                card.addEventListener('mouseenter', function() {
                    if (window.innerWidth > 768) {
                        this.style.transform = 'translateY(-4px)';
                    }
                });

                card.addEventListener('mouseleave', function() {
                    if (window.innerWidth > 768) {
                        this.style.transform = 'translateY(0)';
                    }
                });
            });

            // Smooth animations on scroll (desktop only)
            if (window.innerWidth > 768 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                const cards = document.querySelectorAll('.luxury-card');

                const observer = new IntersectionObserver((entries) => {
                    entries.forEach((entry, index) => {
                        if (entry.isIntersecting) {
                            setTimeout(() => {
                                entry.target.style.opacity = '1';
                                entry.target.style.transform = 'translateY(0)';
                            }, index * 100);
                        }
                    });
                }, {
                    threshold: 0.1
                });

                cards.forEach(card => {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                    observer.observe(card);
                });
            }

            // Add ripple animation keyframes
            const style = document.createElement('style');
            style.textContent = `
                @keyframes ripple {
                    to {
                        transform: scale(4);
                        opacity: 0;
                    }
                }

                .luxury-card {
                    transition: all 0.3s ease;
                }

                .clickable-card:hover {
                    cursor: pointer;
                }

                @media (max-width: 768px) {
                    .luxury-card:hover {
                        transform: none !important;
                    }
                }

                .bg-purple {
                    background: linear-gradient(135deg, #8B5CF6, #A855F7) !important;
                }

                /* Stat card styling dengan border atas berwarna */
                .stat-card {
                    background: rgba(255, 255, 255, 0.95);
                    backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 16px;
                    padding: 1.5rem;
                    transition: all 0.3s ease;
                    position: relative;
                    overflow: hidden;
                    height: 100%;
                    box-shadow: 0 4px 24px rgba(139, 92, 246, 0.08);
                }

                .stat-card::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    height: 4px;
                    transition: all 0.3s ease;
                }

                /* Border colors untuk setiap card */
                .stat-card-warning::before {
                    background: linear-gradient(90deg, #FFC107, #FF9800);
                }

                .stat-card-purple::before {
                    background: linear-gradient(90deg, #8B5CF6, #A855F7);
                }

                /* Hover effect */
                .stat-card:hover {
                    transform: translateY(-4px);
                    box-shadow: 0 8px 40px rgba(139, 92, 246, 0.15);
                }

                .stat-card:hover::before {
                    height: 6px;
                }

                /* Project card dengan border kiri */
                .project-card {
                    position: relative;
                    overflow: hidden;
                }

                .project-card::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    width: 4px;
                    background: linear-gradient(180deg, #8B5CF6, #A855F7);
                    transition: all 0.3s ease;
                }

                .project-card:hover::before {
                    width: 6px;
                }
            `;
            document.head.appendChild(style);

            // Double click untuk buka detail proyek
            const projectCards = document.querySelectorAll('.project-card');
            let lastClickTime = 0;

            projectCards.forEach(card => {
                card.addEventListener('click', function() {
                    const currentTime = new Date().getTime();
                    const clickGap = 300; // ms

                    if (currentTime - lastClickTime < clickGap) {
                        window.location.href = this.dataset.url;
                    }

                    lastClickTime = currentTime;
                });

                // Efek visual saat di-tap
                card.addEventListener('touchstart', function() {
                    this.style.transform = 'scale(0.98)';
                });

                card.addEventListener('touchend', function() {
                    this.style.transform = '';
                });
            });

            // Line Chart
            const lineCtx = document.getElementById('lineChart').getContext('2d');
            const lineChart = new Chart(lineCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode(collect($weeklyData)->pluck('week'), 15, 512) ?>,
                    datasets: [{
                        label: 'Pendapatan',
                        data: <?php echo json_encode(collect($weeklyData)->pluck('income'), 15, 512) ?>,
                        borderColor: '#10B981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: true
                    }, {
                        label: 'Pengeluaran',
                        data: <?php echo json_encode(collect($weeklyData)->pluck('expense'), 15, 512) ?>,
                        borderColor: '#EF4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        borderWidth: 3,
                        tension: 0.3,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                padding: 20
                            }
                        },
                        tooltip: {
                            callbacks: {
                                title: function(tooltipItems) {
                                    const weekData = <?php echo json_encode($weeklyData, 15, 512) ?>[index];
                                    return weekData.start_date + ' - ' + weekData.end_date;
                                },
                                label: function(context) {
                                    return context.dataset.label + ': Rp ' + context.parsed.y.toLocaleString('id-ID');
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    if (value >= 1000000) {
                                        return 'Rp ' + (value / 1000000).toFixed(1) + ' Jt';
                                    }
                                    return 'Rp ' + value;
                                }
                            }
                        }
                    }
                }
            });

            // Pie Chart
            const pieCtx = document.getElementById('pieChart').getContext('2d');
            const pieChart = new Chart(pieCtx, {
                type: 'pie',
                data: {
                    labels: <?php echo json_encode($pieData['labels'], 15, 512) ?>,
                    datasets: [{
                        data: <?php echo json_encode($pieData['data'], 15, 512) ?>,
                        backgroundColor: <?php echo json_encode($pieData['colors'], 15, 512) ?>,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                usePointStyle: true,
                                padding: 20,
                                font: {
                                    size: 12
                                }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label.split(':')[0] || '';
                                    const value = context.raw || 0;
                                    return `${label}: Rp ${value.toLocaleString('id-ID')}`;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\strack\resources\views/dashboard/index.blade.php ENDPATH**/ ?>